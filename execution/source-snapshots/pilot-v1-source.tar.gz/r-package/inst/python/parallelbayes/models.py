"""Targets in explicit unconstrained coordinates; data are portable JSON values."""
from dataclasses import dataclass
from typing import Callable
import hashlib
import json
import numpy as np
import jax.numpy as jnp
from scipy.special import expit


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False).encode()).hexdigest()


@dataclass
class Model:
    spec: dict
    dimension: int
    log_density: Callable
    reference: Callable
    gradient_reference: Callable
    constrain: Callable
    names: list
    backend: str = "jax"

    @property
    def target_id(self):
        return fingerprint(self.spec)


def make_model(spec):
    spec = json.loads(json.dumps(spec))
    kind = spec.get("kind", "gaussian")
    d = int(spec.get("dimension", 8))
    if d < 1:
        raise ValueError("dimension must be positive")
    if kind == "stan":
        from .stan import stan_model
        return stan_model(spec)
    if kind == "gaussian":
        mean = np.asarray(spec.get("mean", np.zeros(d)), dtype=float)
        covariance = np.asarray(spec.get("covariance", np.eye(d)), dtype=float)
        if mean.shape != (d,) or covariance.shape != (d, d):
            raise ValueError("invalid Gaussian mean/covariance shape")
        if not np.allclose(covariance, covariance.T):
            raise ValueError("covariance must be symmetric")
        np.linalg.cholesky(covariance)
        precision = np.linalg.inv(covariance)
        m, p = jnp.asarray(mean), jnp.asarray(precision)
        logp = lambda q: -0.5 * (q-m) @ p @ (q-m)
        ref = lambda q: -0.5 * np.einsum("i,ij,j->", q-mean, precision, q-mean)
        grad = lambda q: -np.einsum("ij,j->i", precision, q-mean)
        spec.update(mean=mean.tolist(), covariance=covariance.tolist())
    elif kind == "logistic":
        x, y = np.asarray(spec["X"], float), np.asarray(spec["y"], float)
        if x.ndim != 2 or y.shape != (x.shape[0],) or not np.isin(y, [0, 1]).all():
            raise ValueError("X must be a matrix and y a binary observation vector")
        if not np.isfinite(x).all():
            raise ValueError("nonfinite predictors")
        d = x.shape[1]
        scale = float(spec.get("prior_scale", 2.5))
        if scale <= 0:
            raise ValueError("prior_scale must be positive")
        xx, yy = jnp.asarray(x), jnp.asarray(y)
        logp = lambda q: jnp.sum(yy*(xx@q)-jnp.logaddexp(0., xx@q))-0.5*jnp.sum((q/scale)**2)
        ref = lambda q: np.sum(y*(np.einsum("ij,j->i", x, q))-np.logaddexp(0., np.einsum("ij,j->i", x, q)))-0.5*np.sum((q/scale)**2)
        grad = lambda q: np.einsum("ij,i->j", x, y-expit(np.einsum("ij,j->i", x, q)))-q/scale**2
        spec.update(prior_scale=scale)
    elif kind == "lognormal":
        # theta = exp(q); lognormal density includes -log(theta), cancelled by Jacobian q.
        d = 1
        mu, sd = float(spec.get("mu", 0.)), float(spec.get("sigma", 1.))
        if sd <= 0:
            raise ValueError("sigma must be positive")
        logp = lambda q: -0.5*jnp.sum(((q-mu)/sd)**2)
        ref = lambda q: -0.5*np.sum(((q-mu)/sd)**2)
        grad = lambda q: -(q-mu)/sd**2
        spec.update(mu=mu, sigma=sd)
    elif kind == "normal_mean":
        # Conjugate generative fixture for end-to-end SBC (prior N(0,1), noise sd=1).
        d = 1
        y = np.asarray(spec["y"], float)
        yy = jnp.asarray(y)
        logp = lambda q: -0.5*jnp.sum(q*q)-0.5*jnp.sum((yy-q[0])**2)
        ref = lambda q: -0.5*np.sum(q*q)-0.5*np.sum((y-q[0])**2)
        grad = lambda q: np.asarray([np.sum(y)-(len(y)+1)*q[0]])
    else:
        raise ValueError(f"unsupported target kind: {kind}")
    spec["kind"], spec["dimension"] = kind, d
    spec.setdefault("coordinate_id", "log-positive" if kind == "lognormal" else "identity")
    transform = np.exp if kind == "lognormal" else lambda q: q
    return Model(spec, d, logp, ref, grad, transform,
                 ["theta" if kind == "lognormal" else f"q[{i+1}]" for i in range(d)])


def benchmark_model(name, seed=20261003):
    rng = np.random.default_rng(np.random.SeedSequence([seed, 11]))
    if name == "G1":
        return make_model({"kind": "gaussian", "dimension": 8})
    if name == "G2":
        rotation, _ = np.linalg.qr(rng.normal(size=(64, 64)))
        cov = np.einsum("ik,jk,k->ij", rotation, rotation, np.geomspace(1., 100., 64))
        return make_model({"kind": "gaussian", "dimension": 64, "covariance": cov.tolist()})
    if name in ("L1", "L2"):
        n = 256 if name == "L1" else 4096
        data_rng = np.random.default_rng(np.random.SeedSequence([seed, 12, n]))
        beta = rng.normal(0, 2.5, 8)
        x = data_rng.normal(size=(n, 8))
        x[:, 0] = 1
        x[:, 1:] = (x[:, 1:]-x[:, 1:].mean(0))/x[:, 1:].std(0)
        y = data_rng.binomial(1, expit(np.einsum("ij,j->i", x, beta)))
        return make_model({"kind": "logistic", "X": x.tolist(), "y": y.tolist(),
                           "generator_seed": seed, "generator_beta": beta.tolist()})
    if name == "T1":
        return make_model({"kind": "lognormal"})
    raise ValueError(f"unknown benchmark: {name}")

