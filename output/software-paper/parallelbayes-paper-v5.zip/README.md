# ParallelBayes 中文论文 v5 可编译输入

主文件：`manuscript/software/软件与基准研究.tex`。
补充A：`manuscript/software/补充材料.tex`。
补充B：`complete-results/report.tex`。

安装Tectonic（ctex/Fandol字体）或完整TeX Live的XeLaTeX后，在本包根目录运行 `python BUILD.py`，编译三份PDF并生成日志/校验记录；可指定 `--compiler /绝对路径/tectonic`。只核对源文件可运行 `python BUILD.py --verify-only`。不需Codex专用插件。所有input及图件保留相对路径，可搬移到任意新目录。此包重建论文图文；完整实验重放另需原数组、协议与源码环境，见仓库复现指南。

v4原稿/协议/结果保持，本包包含v5新论证、既有计时/诊断再分析与单独R技术示例摘要。未启动新正式采样，未改变旧失败/成功数、区间和参考类别。作者、期刊与长期公开原件标识尚待决定。附带的部分分析脚本供溯源；要运行这些分析，应克隆对应版本的完整仓库、安装锁定依赖并取得原件。本包是完整图文编译输入，不是完整数值复现原件包。
