# 中文论文独立构建输入

此包仅用于从已生成的LaTeX与矢量图编译当前研究稿。它不包含正式原始数组、完整分析代码或R包，不能代替实验复现包，也不表明研究已经完成。

先校验MANIFEST.json的每项SHA256。使用已有Tectonic（本次为0.17.0，中文依赖已缓存）或具备ctex/fandol的完整XeLaTeX。无需访问原作者的绝对路径。首次无缓存Tectonic可能需要获取其TeX资源。

```text
cd manuscript/software
tectonic 软件与基准研究.tex
tectonic 补充材料.tex
```

或在同目录使用`latexmk -xelatex 软件与基准研究.tex`。编译器资源与字体不随包再分发。各协议数字由生成文本保留；历史结果与前瞻方法已明确分开。对正文数字的独立复算须另取仓库源码、协议及相应原始证据。紧凑研究已完成独立全量重建；主文、补充材料及另附的完整结果报告注明各自证据范围。正文和补充材料应分别编译。

本包另含完整结果附录：在complete-results目录运行tectonic report.tex。45幅图和CSV来源表随包提供；完整统计与原始轨迹另取指定证据包。
